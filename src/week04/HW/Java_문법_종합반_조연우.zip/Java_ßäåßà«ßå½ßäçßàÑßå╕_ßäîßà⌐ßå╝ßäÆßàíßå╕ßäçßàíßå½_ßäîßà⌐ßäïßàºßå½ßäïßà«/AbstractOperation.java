package week04.HW.Java_문법_종합반_조연우;

public abstract class AbstractOperation {
    public abstract double operate(int firstNumber, int secondNumber);
}
