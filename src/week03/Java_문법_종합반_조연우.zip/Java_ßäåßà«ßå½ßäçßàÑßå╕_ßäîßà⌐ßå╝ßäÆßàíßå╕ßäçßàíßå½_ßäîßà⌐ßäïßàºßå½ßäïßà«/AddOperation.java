package week03.Java_문법_종합반_조연우;

public class AddOperation extends AbstractOperation {

    @Override
    public double operate (int firstNumber, int secondNumber){
        return firstNumber + secondNumber;
    }
}
